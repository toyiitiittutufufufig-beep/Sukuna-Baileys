# Sukuna helpers (src/Utils/sukuna-helpers.ts)
أزرار: replyButton · urlButton · copyButton · callButton · listButton
إرسال: sendButtons(sock, jid, {title?, body, footer?, buttons}) · sendRichHtml(sock, jid, {title, html, url})
JID: jidToNumber · numberToJid · isGroupJid · isNewsletterJid · isLidJid · parseMentions
نصوص: chunkText · formatBytes · formatDuration
تحكّم: sleep · withTimeout · retry · sendToMany · TTLCache

# Sukuna Pro (src/Utils/sukuna-pro.ts)
waitForReply(sock, chat, {from, timeoutMs}) · ask(sock, chat, سؤال, ['نعم','لا']) · waitForButton(sock, chat, ids)
liveMessage(sock, chat, نص) → .progress(40,'تحميل') .done('✅') .edit() .remove()   (رسالة واحدة بتتعدّل)
sendHuman(sock, chat, {text})  ← "يكتب..." بمدة مناسبة قبل الإرسال
createSendQueue(sock, {perSecond, perChatMs}) ← طابور إرسال ذكي بدون ضياع رسائل
paginate(sock, chat, pages, {from}) ← صفحات بأزرار التالي/السابق
createCooldown · createDeduper · scheduleAt · createRouter · fancy.* · boxText · progressBar · reconnectDelay

## resolveNumber / getUserNumber — من LID إلى رقم الهاتف

```js
import { resolveNumber, getUserNumber } from '@whiskeysockets/baileys'

// داخل الـ handler
const num = await getUserNumber(conn, m.sender, { groupJid: m.isGroup ? m.chat : undefined, key: m.key })
// "201012345678" أو null

const r = await resolveNumber(conn, m.sender, { groupJid: m.chat })
// { number, jid, lid, source: 'pn' | 'key' | 'group' | 'mapping' | 'none' }
```
الترتيب: jid عادي ← حقول participantAlt/remoteJidAlt في الرسالة ← أعضاء الجروب ← جدول ربط LID↔PN (محلي ثم سيرفر واتساب).
يوزرنيم واتساب (@username) مقفول عمداً ومفيش طريقة يتحوّل لرقم، فبيرجع `number: null`.
